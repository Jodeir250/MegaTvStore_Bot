from pyrogram import Client, filters
from pyrogram.types import (
    CallbackQuery,
    ForceReply,
    InlineKeyboardButton,
    InlineKeyboardMarkup,
)

from database import cur, save
from utils import get_info_wallet, dobrosaldo, get_login_count



@Client.on_callback_query(filters.regex(r"^user_info$"))
async def user_info(c: Client, m: CallbackQuery):
    kb = InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(
                    "🤑 𝑨𝑭𝑰𝑳𝑰𝑨𝑫𝑶", callback_data="afiliados"
                ),
                InlineKeyboardButton("🧾 𝑯𝑰𝑺𝑻𝑶𝑹𝑰𝑪𝑶", callback_data="buy_history"),
            ],
            [
                 InlineKeyboardButton("𝑮𝑹𝑼𝑷𝑶 𝑫𝑬 𝑪𝑳𝑰𝑬𝑵𝑻𝑬𝑺", url="https://t.me/megatvdigitalstore"),
             ],
             [
                 InlineKeyboardButton("👨‍💄1�7 𝑫𝑶𝑵𝑶", url="t.me/MegaTvdigital"),
             ],
             [
                 InlineKeyboardButton("⏄1�7 𝑴𝑬𝑵𝑼 𝑷𝑹𝑰𝑵𝑪𝑰𝑷𝑨𝑳", callback_data="start"),
             ],

        ]
    )
	# Buscar a quantidade de logins comprados pelo usuário
    login_count = get_login_count(m.from_user.id)

    link = f"https://t.me/{c.me.username}?start={m.from_user.id}"
    await m.edit_message_text(
         f"""<b>📛 Nome: {m.from_user.first_name}</b>
<b>🆔 ID da carteira: {m.from_user.id}</b>
<b>🎟 Contas comprads: {login_count}</b>

{get_info_wallet(m.from_user.id)}""",
        reply_markup=kb,
	)
    
@Client.on_callback_query(filters.regex(r"^gift$"))
async def gift(c: Client, m: CallbackQuery):
    kb = InlineKeyboardMarkup(
        inline_keyboard=[
            
            
             [
                 InlineKeyboardButton("❄1�7 ❄1�7", callback_data="start"),
             ],

        ]
    )
    link = f""
    await m.edit_message_text(
        f"""<b>🎁 Resgatar Gift</b>
<i>- Aqui você resgatar o gift com facilidade,digite seu gift como o exemplo abaixo.</i>

<i>🏷 - Exemplo: /resgatar FOX0FCOT7OTH </i>

{get_info_wallet(m.from_user.id)}""",
        reply_markup=kb,
    )
@Client.on_callback_query(filters.regex(r"dv$"))
async def dv(c: Client, m: CallbackQuery):
    kb = InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton("❄1�7 ❄1�7", callback_data="user_info"),
            ],
             [
                 InlineKeyboardButton("⚜️ Alugue Seu Bot", url="https://t.me/AuroraCc_On"),
             ],
        ]
    )

    await m.edit_message_text(
        f"""<b>⚙️ | Versão do bot: 3.8</b>

<b> ➄1�7 Ultima atualização: 19/06/2024 </b>

<b> ➄1�7 Sistema Automatico De Banimentos </b>

<b> ➄1�7 Sistema com Auto Reiniciamento </b>

<b> ➄1�7 Sistema Atualizado com gifts </b>

<b> ➄1�7 Sistema de Pontos </b>

<b> ➄1�7 Sistema de Referência </b>

<b> ➄1�7 Pix com MP </b>

<b> ➄1�7 QR Code Gerando Imagem </b>

<b> ➄1�7 Mude o Pix com 1 Click </b>

<b> ➄1�7 Sistema de ADMIN completo </b>

<b> ➄1�7 COMPRA VIA "INLINE"  FUNCIONANDO</b>

<b> ➄1�7 Logins via Inline Com Imagens </b>

<b> ➄1�7 Bloqueio automático de bancos específicos
(estorna automaticamente uma adição de saldo feita por banco inter ou picpay por exemplo, para evitar possíveis estornos de pessoas más intencionadas)</b>

<b> ✄1�7 | Bot by: @AuroraCc_On </b>""",
  reply_markup=kb,
    )

@Client.on_callback_query(filters.regex(r"^buy_history$"))
async def buy_history(c: Client, m: CallbackQuery):
    kb = InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton("❄1�7 ❄1�7", callback_data="user_info"),
            ],
        ]
    )
    history = cur.execute(
        "SELECT tipo, email, senha, cidade, bought_date FROM docs_sold WHERE owner = ? ORDER BY bought_date DESC LIMIT 10",
        [m.from_user.id],
    ).fetchall()

    if not history:
        cards_txt = "<b>⚠️ Não há nenhuma compra nos Registros.</b>"
    else:
        cards_txt = "<b>🎫 Histórico de compras:</b>\n"
        for idx, card in enumerate(history, start=1):
            tipo, email, senha, cidade, bought_date = card
            cards_txt += f"<b>Compra {idx}:</b>\n"
            cards_txt += f"- Tipo: {tipo}\n"
            cards_txt += f"- Email: {email}\n"
            cards_txt += f"- Senha: {senha}\n"
            cards_txt += f"- Cidade: {cidade}\n"
            cards_txt += f"- Data da Compra: {bought_date}\n\n"

    await m.edit_message_text(
        cards_txt,
        reply_markup=kb,
    )


@Client.on_callback_query(filters.regex(r"^swap$"))
async def swap_points(c: Client, m: CallbackQuery):
    kb = InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton("❄1�7 ❄1�7", callback_data="start"),
            ],
        ]
    )

    user_id = m.from_user.id
    balance, diamonds = cur.execute(
        "SELECT balance, balance_diamonds FROM users WHERE id=?", [user_id]
    ).fetchone()

    if diamonds >= 50:
        add_saldo = round((diamonds / 2), 2)
        new_balance = round((balance + add_saldo), 2)

        txt = f"🧪 Seus <b>{diamonds}</b> pontos foram convertidos em R$ <b>{add_saldo}</b> de saldo."

        cur.execute(
            "UPDATE users SET balance = ?, balance_diamonds=?  WHERE id = ?",
            [new_balance, 0, user_id],
        )
        return await m.edit_message_text(txt, reply_markup=kb)

    await m.answer(
        "⚠️ Você não tem pontos suficientes para realizar a troca. O mínimo é 50 pontos.",
        show_alert=True,
    )


@Client.on_callback_query(filters.regex(r"^swap_info$"))
async def swap_info(c: Client, m: CallbackQuery):
    await m.message.delete()

    cpf = await m.message.ask(
        "<b>👤 CPF da lara (exemplo: 30599385120)</b>",
        reply_markup=ForceReply(),
        timeout=120,
    )
    name = await m.message.ask(
        "<b>👤 Nome completo do pagador (exemplo: wilma bernadete de almeida borba)</b>", reply_markup=ForceReply(), timeout=120
    )
    email = await m.message.ask(
        "<b>📧 E-mail (exemplo: salmos91@gmail.com)</b>", reply_markup=ForceReply(), timeout=120
    )
    cpf, name, email = cpf.text, name.text, email.text
    cur.execute(
        "UPDATE users SET cpf = ?, name = ?, email = ?  WHERE id = ?",
        [cpf, name, email, m.from_user.id],
    )
    save()

    kb = InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton("❄1�7 ❄1�7", callback_data="start"),
            ]
        ]
    )
    await m.message.reply_text(
        "<b> ✄1�7 Seus dados foram alterados com sucesso.</b>", reply_markup=kb
    )

from pyrogram import Client, filters
from pyrogram.types import (
    CallbackQuery,
    ForceReply,
    InlineKeyboardButton,
    InlineKeyboardMarkup,
)

from database import cur, save
from utils import get_info_wallet

import datetime
from typing import Union
import asyncio

@Client.on_callback_query(filters.regex(r"^afiliados$"))
async def afiliados(c: Client, m: CallbackQuery):
    kb = InlineKeyboardMarkup(
        inline_keyboard=[            
             [
                 InlineKeyboardButton("📌 COMPARTILHAR", url=f"https://t.me/share/url?url=https://t.me/{c.me.username}?start={m.from_user.id}"),
				         InlineKeyboardButton("🧪 TROCAR PONTOS", callback_data="swap"),
				     ],
		      	 [
				         InlineKeyboardButton("⬅️ Menu Principal", callback_data="user_info"),
             ],
        ]
    )
    link = f"https://t.me/{c.me.username}?start={m.from_user.id}"
    await m.edit_message_text(
                f"""<b>🤑 GANHAR POR INDICAÇÃO 🤑</b>

<b>COPIE O SEU LINK DE AFILIADO E DIVULGUE ‼️‼️</b>

<b>🔗 SEU LINK:<code>{link}</code></b>
<i>(basta clicar no link)</i>

<b>🧪 Sempre que alguém entrar no bot pelo seu link, você será avisado!</b>

<b>🧪 E o melhor: você ganha 10% de saldo na loja toda vez que seu indicado fizer um depósito no bot. 🔥</b>

<b>Dúvidas? Suporte: @MegaTvdigital</b>""",
        reply_markup=kb,	
	)
import asyncio
import sqlite3
from pyrogram import Client, filters
from pyrogram.types import (
    CallbackQuery,
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    InlineQuery,
    InlineQueryResultArticle,
    InputTextMessageContent,
)

from config import ADMIN_CHAT
from config import GRUPO_PUB
from config import BOT_LINK
from config import BOT_LINK_SUPORTE
from database import cur, save
from utils import (
    create_mention,
    get_info_wallet,
    get_price,
    insert_docs_sold,
    insert_sold_balance,
    lock_user_buy,
    msg_buy_off_user,
    msg_buy_user,
    msg_group_adm,
    msg_group_publico,
)



SELLERS, TESTED = 0, 0


T = 0.1





# Listagem de tipos de compra.
@Client.on_callback_query(filters.regex(r"^comprar_log$"))
async def comprar_doc_list(c: Client, m: CallbackQuery):
    kb = InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton("🎟 LOGINS | CONTAS PREMIUM", callback_data="comprar_login unit"),
                
                
            ],
          

             
            [
                InlineKeyboardButton("🔙 Voltar", callback_data="start"),
            ],
        ]
    )

    await m.edit_message_text(
        f"""
 <b>🎟 LOGINS STREAMING</b>

{get_info_wallet(m.from_user.id)}""",
        reply_markup=kb,
    )


# Pesquisa de CCs via inline.
@Client.on_inline_query(filters.regex(r"^buscar_(?P<type>\w+) (?P<value>.+)"))
async def search_cc(c: Client, m: InlineQuery):
    """
    Pesquisa uma documentos via inline por tipo e retorna os resultados via inline.

    O parâmetro `type` será o tipo de valor para pesquisar
    """

    typ = m.matches[0]["type"]
    qry = m.matches[0]["value"]

    # Não aceitar outros valores para prevenir SQL Injection.
    if typ not in ("tipo", "cidade", "city", "type"):
        return

    if typ != "bicos":
        qry = f"%{qry}%"

    if typ == "tipo":
        typ2 = "tipo"
        typ3 = "tipo"
    elif typ == "cidade":
        typ2 = "tipo"
        typ3 = "cidade"
    elif typ == "city":
        typ2 = "tipo"
        typ3 = "cidade"
    else:
        typ2 = typ

    rt = cur.execute(
        f"SELECT email,  {typ2}, idlogin, cidade FROM docscnh WHERE {typ3} LIKE ? AND pending = 0 ORDER BY RANDOM() LIMIT 40",
        [qry.upper()],
    ).fetchall()

    results = []
    results.append(
            InlineQueryResultArticle(
                title=f"Total: ({len(rt)}) de resultados encontrados",
                description="Confira todos os logins abaixo 🛍👇",
                
                input_message_content=InputTextMessageContent(
                    "Escolha o Login Pelo Nome ✅"
                ),
            )
        )

    wallet_info = get_info_wallet(m.from_user.id)

    for email, value, idlogin, cidade in rt:

        price = await get_price("docs", value)

        base = f"""Email: {email[0:6]}********** Tipo: {value} City: {cidade}"""

        base_ml = f"""<b>Email:</b> <i>{email[0:6]}**********</i>
<b>Tipo:</b> <i>{value}</i>
<b>Cidade:</b> <i>{cidade}</i>

<b>Valor:</b> <i>R$ {price}</i>"""

        kb = InlineKeyboardMarkup(
            inline_keyboard=[
                [
                    InlineKeyboardButton(
                        text="✅ Comprar",
                        callback_data=f"buy_off tipo '{value}'",
                    )
                ]
            ]
        )

        results.append(
            InlineQueryResultArticle(
                title=f"{typ} {value} - R$ {price}",
                description=base,
                
                input_message_content=InputTextMessageContent(
                    base_ml + "\n\n" + wallet_info
                ),
                reply_markup=kb,
            )
        )

    await m.answer(results, cache_time=5, is_personal=True)
    

# Opção Compra de CCs e Listagem de Level's.
@Client.on_callback_query(filters.regex(r"^comprar_login unit$"))
async def comprar_ccs(c: Client, m: CallbackQuery):
    list_levels_cards = cur.execute("SELECT tipo FROM docscnh GROUP BY tipo").fetchall()
    levels_list = [x[0] for x in list_levels_cards]

    if not levels_list:
        return await m.answer(
            "⚠️ Não há logins disponíveis no momento, tente novamente mais tarde.",
            show_alert=True,
        )

    levels = []
    for level in levels_list:
        level_name = level
        n = level.split()
        if len(n) > 1:
            level_name = n[0][:4] + " " + n[1]

        price = await get_price("docs", level)
        levels.append(
            InlineKeyboardButton(
                text=f"🧪 {level_name.upper()} | R$ {price}",
                callback_data=f"confirm_purchase tipo '{level}' {level}",  # Modificado para incluir confirmação
            )
        )

    organ = (
        lambda data, step: [data[x : x + step] for x in range(0, len(data), step)]
    )(levels, 2)
    table_name = "docscnh"
    ccs = cur.execute(
        f"SELECT tipo, count() FROM {table_name} GROUP BY tipo ORDER BY count() DESC"
    ).fetchall()

    
    total = f"\n\n<b>TOTAL</b>: {sum([int(x[1]) for x in ccs])}" if ccs else ""
    
    organ.append([InlineKeyboardButton(text="❮ ❮", callback_data="start")])
    kb = InlineKeyboardMarkup(inline_keyboard=organ)
    await m.edit_message_text(
        f"""<b>Comprar LOGIN</b>
{total}

{get_info_wallet(m.from_user.id)}""",
        reply_markup=kb,
    )

# Etapa de confirmação de compra
@Client.on_callback_query(filters.regex(r"^confirm_purchase (?P<type>[a-z]+) '(?P<level_cc>.+)' ?(?P<other_params>.+)?"))
async def confirm_purchase(c: Client, m: CallbackQuery):
    # Dados da compra
    type_cc = m.matches[0]["type"]
    level_cc = m.matches[0]["level_cc"]
    other_params = m.matches[0]["other_params"]

    # Preço do item
    price = await get_price("docs", other_params)

    # Mensagem de confirmação
    confirm_markup = InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton("✅ Confirmar", callback_data=f"buy_off {type_cc} '{level_cc}' {other_params}")],
            [InlineKeyboardButton("❌ Cancelar", callback_data="comprar_login unit")]
        ]
    )

    # Resposta rápida para ocultar o "loading" no botão
    await m.answer()

    # Atualizar a mensagem original com as opções de confirmação
    await m.message.edit_text(
        f"Você está prestes a comprar a conta <b>{level_cc}</b> por <b>R$ {price}</b>. Deseja confirmar?",
        reply_markup=confirm_markup
    )


@Client.on_callback_query(
    filters.regex(r"^buy_off (?P<type>[a-z]+) '(?P<level_cc>.+)' ?(?P<other_params>.+)?")  # fmt: skip
)
@lock_user_buy
async def buy_off(c: Client, m: CallbackQuery):
    user_id = m.from_user.id
    balance: int = cur.execute("SELECT balance FROM users WHERE id = ?", [user_id]).fetchone()[0]  # fmt: skip

    type_cc = m.matches[0]["type"]
    level_cc = m.matches[0]["level_cc"]

    price = await get_price("docs", level_cc)

    if balance < price:
        return await m.answer(
            "⚠️ Você não possui saldo suficiente para esse item. Por favor, faça uma transferência usando /pix.",
            show_alert=True,
        )

    search_for = "tipo" if type_cc == "tipo" else "idlogin"

    selected_cc = cur.execute(
        f"SELECT tipo, email, senha, added_date, cidade, idlogin FROM docscnh WHERE {search_for} = ? AND pending = ? ORDER BY RANDOM()",
        [level_cc, False],
    ).fetchone()

    if not selected_cc:
        return await m.answer("⚠️ Sem contas disponiveis para este nivel.", show_alert=True)

    diamonds = round(((price / 100) * 8), 2)
    new_balance = balance - price
    
    (
        tipo,
        email,
        senha,
        added_date,
        cidade,
        idlogin,
    ) = selected_cc
    #nome = nome.upper()
    card = "|".join([tipo, email, senha])
    ds = "docs"
    list_card_sold = selected_cc + (user_id, ds)

    cur.execute(
        "DELETE FROM docscnh WHERE idlogin = ?",
        [selected_cc[5]],
    )

    cur.execute(
        "UPDATE users SET balance = ?, balance_diamonds = round(balance_diamonds + ?, 2) WHERE id = ?",
        [new_balance, diamonds, user_id],
    )

    s = insert_docs_sold(list_card_sold)
    print(s)
    insert_sold_balance(price, user_id, "docs")

    #dados = (cpf, name) if cpf is not None else None
    base = await msg_buy_off_user(user_id, email, senha, tipo, price, cidade)
    kb = InlineKeyboardMarkup(
        inline_keyboard=[
			[
                InlineKeyboardButton(text="🔄 𝑻𝑹𝑶𝑪𝑨𝑹 𝑳𝑶𝑮𝑰𝑵", url="https://t.me/MegaTvdigital"),
            ],
			
			[
                InlineKeyboardButton(text="✅️ 𝑪𝑶𝑴𝑷𝑹𝑨𝑹 𝑵𝑶𝑽𝑨𝑴𝑬𝑵𝑻𝑬", callback_data="comprar_login unit"),
            ],
			
        ]
	)

    await m.edit_message_text(base, reply_markup=kb)
    mention = create_mention(m.from_user)
    adm_msg = msg_group_adm(
        mention, email, senha, tipo, price, "None", new_balance, cidade
    )
    pub = msg_group_publico(mention, email, senha, tipo, price, "None", new_balance, cidade)
    await c.send_message(ADMIN_CHAT, adm_msg)
    kb = InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(text="🎟 Compre os melhores streamings",url=f"https://t.me/MegaTvStore_Bot"),
            ],
        ]
	)
    await c.send_message(GRUPO_PUB, pub, reply_markup=kb)

    save()
from pyrogram import Client, filters
from pyrogram.types import Message
from config import ADMINS

# Variável global para armazenar o texto da tabela
tabela_text = "Texto da tabela padrão"

# Comando para editar a tabela (apenas para administradores)
@Client.on_message(filters.command("editar_tabela") & filters.user(ADMINS))
async def editar_tabela(c: Client, m: Message):
    global tabela_text
    if len(m.text.split(maxsplit=1)) < 2:
        await m.reply("Por favor, forneça o novo texto da tabela após o comando.")
        return
    tabela_text = m.text.split(maxsplit=1)[1]
    await m.reply("Texto da tabela atualizado com sucesso!")

# Comando para visualizar a tabela (para todos os usuários)
@Client.on_message(filters.command("tabela"))
async def valores(c: Client, m: Message):
    global tabela_text
    await m.reply(tabela_text)
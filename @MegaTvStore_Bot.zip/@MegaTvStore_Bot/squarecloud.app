DISPLAY_NAME=MegaTvStore_Bot
MAIN=bot.py
VERSION=recommended
MEMORY=550    
AUTORESTART=true
DESCRIPTION=Meu Bot de Logins
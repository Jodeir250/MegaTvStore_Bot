import ast

UP_FILE = 'config.py'

def save(key, value):
    with open(UP_FILE, 'r', encoding='utf-8', errors='replace') as file:
        lines = file.readlines()

    for i, line in enumerate(lines):
        if key in line and '=' in line:
            lines[i] = f"{key} = {value}\n"
            break

    with open(UP_FILE, 'w', encoding='utf-8', errors='replace') as file:
        file.writelines(lines)

def load(key):
    try:
        with open(UP_FILE, 'r', encoding='utf-8', errors='replace') as file:
            lines = file.readlines()
            for line in lines:
                if key in line and '=' in line:
                    value_part = line.split('=')[1].strip()
                    return [int(id.strip()) for id in value_part.strip('[]').split(',')]
    except (FileNotFoundError, ValueError):
        return []

def add_admin(admin_id):
    if admin_id not in ADMINS:
        ADMINS.append(admin_id)
        save("ADMINS", ADMINS)
        return True
    else:
        return False

def remove_admin(admin_id):
    if admin_id in ADMINS:
        ADMINS.remove(admin_id)
        save("ADMINS", ADMINS)
        return True
    else:
        return False
        
def get_admin_list():
    return ADMINS
	
BOT_TOKEN = "7172369621:AAExeHQmLtA0Y2eWimBRJuNFdoP3vtahu2o"
API_HASH = "72dde09e2f88dbe13e0a1dbbc1a88656"
API_ID = "29494285"
WORKERS = 20
ADMIN_CHAT = 5156828295
LOG_CHAT = 5156828295
GRUPO_PUB = -1002115309059
ADMINS = [5156828295]
SUDOERS = [5156828295]
ADMINS.extend(SUDOERS)
GIFTERS = []
BOT_LINK = "MegaTvStore_Bot"
BOT_LINK_SUPORTE = "MegaTvdigital"
